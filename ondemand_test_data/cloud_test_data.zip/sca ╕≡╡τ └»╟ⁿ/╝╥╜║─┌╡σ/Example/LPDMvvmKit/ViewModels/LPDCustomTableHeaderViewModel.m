//
//  LPDCustomTableHeaderViewModel.m
//  LPDMvvmKit
//
//  Created by 彭柯柱 on 16/2/2.
//  Copyright © 2016年 eleme. All rights reserved.
//

#import "LPDCustomTableHeaderViewModel.h"

@implementation LPDCustomTableHeaderViewModel

@end
