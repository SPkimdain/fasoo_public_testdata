//
//  LPDCustomCellModel.h
//  LPDMvvmKit
//
//  Created by 彭柯柱 on 16/2/1.
//  Copyright © 2016年 eleme. All rights reserved.
//

#import "LPDTableCellViewModel.h"

@interface LPDCustomCellModel : LPDTableCellViewModel

@property (nonatomic, copy) NSString *myText;

@property (nonatomic, copy) NSString *rows;

@end
