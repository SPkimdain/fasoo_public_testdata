//
//  LPDCustomTableHeaderViewModel.h
//  LPDMvvmKit
//
//  Created by 彭柯柱 on 16/2/2.
//  Copyright © 2016年 eleme. All rights reserved.
//

#import "LPDTableHeaderViewModel.h"

@interface LPDCustomTableHeaderViewModel : LPDTableHeaderViewModel

@property (nonatomic, copy) NSString *myText;

@end
