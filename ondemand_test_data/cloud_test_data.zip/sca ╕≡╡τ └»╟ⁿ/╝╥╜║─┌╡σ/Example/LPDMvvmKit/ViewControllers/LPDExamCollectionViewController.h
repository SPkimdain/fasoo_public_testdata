//
//  LPDExamCollectionViewController.h
//  LPDMvvmKit
//
//  Created by 李博 on 16/2/29.
//  Copyright © 2016年 eleme. All rights reserved.
//

#import "LPDScrollViewController.h"

@interface LPDExamCollectionViewController : LPDScrollViewController

@end
