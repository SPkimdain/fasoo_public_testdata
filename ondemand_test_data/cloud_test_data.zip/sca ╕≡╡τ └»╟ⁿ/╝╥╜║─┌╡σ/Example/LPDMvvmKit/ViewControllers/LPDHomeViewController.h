//
//  LPDHomeViewController.h
//  LPDMvvmKit
//
//  Created by foxsofter on 15/12/16.
//  Copyright © 2015年 eleme. All rights reserved.
//

#import <LPDMvvmKit/LPDMvvmKit.h>

@interface LPDHomeViewController : LPDViewController

@end
