//
//  LPDExamTableViewController.h
//  LPDMvvmKit
//
//  Created by foxsofter on 15/12/16.
//  Copyright © 2015年 eleme. All rights reserved.
//

#import "LPDScrollViewController.h"

@interface LPDExamTableViewController : LPDScrollViewController

@end
