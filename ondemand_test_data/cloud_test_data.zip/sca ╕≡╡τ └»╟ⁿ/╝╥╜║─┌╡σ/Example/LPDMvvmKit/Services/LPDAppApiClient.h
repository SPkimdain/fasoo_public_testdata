//
//  LPDAppApiClient.h
//  LPDMvvmKit
//
//  Created by foxsofter on 16/9/21.
//  Copyright © 2016年 eleme. All rights reserved.
//

#import <LPDMvvmKit/LPDMvvmKit.h>

@interface LPDAppApiClient : LPDApiClient

+ (instancetype)sharedInstance;

@end
