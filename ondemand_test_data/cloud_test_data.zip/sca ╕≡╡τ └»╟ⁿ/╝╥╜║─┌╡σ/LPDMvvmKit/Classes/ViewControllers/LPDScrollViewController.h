//
//  LPDScrollViewController.h
//  LPDMvvmKit
//
//  Created by foxsofter on 15/12/13.
//  Copyright © 2015年 eleme. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MJRefresh/MJRefresh.h>
#import "LPDViewController.h"
#import "LPDScrollViewControllerProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface LPDScrollViewController : LPDViewController <LPDScrollViewControllerProtocol>

@end

NS_ASSUME_NONNULL_END
