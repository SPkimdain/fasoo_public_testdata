public class Link2 {
    public static String func2 (String a2){
        a2 = Link1.func1("1");

        return a2;
    }
}
