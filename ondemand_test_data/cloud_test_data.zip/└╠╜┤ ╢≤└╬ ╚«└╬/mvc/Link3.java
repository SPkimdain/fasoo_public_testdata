public class Link3 {
    public static String func3 (String password){
        password = Link2.func2("2");

        return password;
    }
}
