public class Link1 {
    public static String func1 (String a1){
        a1 = "1";

        return a1;
    }
}
